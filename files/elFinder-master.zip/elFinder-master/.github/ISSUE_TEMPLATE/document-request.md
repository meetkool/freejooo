---
name: Document request
about: Request to maintain elFinder documentation
title: "[DOC] "
labels: documentation
assignees: ''

---

** What is your document request related to? Please describe. **
A clear and concise explanation of what you feel unclear. Example Always frustrated […]

** Additional context **
Add other contexts or screenshots for feature requests here.

** Anyone can create a document **
Anyone can edit the Wiki page. We are always looking for someone to resolve this request!
